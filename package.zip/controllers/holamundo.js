'use strict'

function saludar(req, resp){
    resp.status(200).send({message: "hola mundo"

    });
}

module.exports = {
    saludar
}
