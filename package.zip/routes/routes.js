'use strict'

var express = require('express');
var holaMundoController = 
        require('../controllers/holamundo')

var routes = express.Router();

routes.get('/api/saludar',
    holaMundoController.saludar);

module.exports = routes;
